RynPay Android APK project
==========================
The HTML app is bundled into a WebView.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. APK will be under app/build/outputs/apk/debug/.

Application ID: com.ryn.pay
App name: RynPay
